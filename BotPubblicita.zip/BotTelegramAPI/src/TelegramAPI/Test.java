/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TelegramAPI;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.stream.Collectors;
import org.json.*;

/**
 *
 * @author marini_alessio
 */
public class Test {
    
    public void foo(String azione) throws MalformedURLException, IOException {
        
        String f = "https://api.telegram.org/bot5199935935:AAFMcHp5SZNWk49S4fSUH4itKo99t1PIIpA/" + azione;
        URL request = new URL("https://api.telegram.org/bot5199935935:AAFMcHp5SZNWk49S4fSUH4itKo99t1PIIpA/" + azione);
        
        String result = new BufferedReader(new InputStreamReader(request.openStream())).lines().collect(Collectors.joining("\n"));
        System.out.println(result);

        
//        String jsonString = "{nome:'mario',messaggi:['ciao','mondo']}"; //assign your JSON String here
//        JSONObject obj = new JSONObject(jsonString);
//        String name = obj.getString("nome");
//        System.out.println(name);
//        JSONArray arr = obj.getJSONArray("messaggi"); // notice that `"posts": [...]`
//        for (int i = 0; i < arr.length(); i++) {
//            String messaggio = arr.getString(i);
//            System.out.println(messaggio);
//        }
    }

}

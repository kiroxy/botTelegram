/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

/**
 *
 * @author marini_alessio
 */
public class Persona {
    String nome; 
    String citta;
    long chatID;

    public Persona(String nome, String citta, long chatID) {
        this.nome = nome;
        this.citta = citta;
        this.chatID = chatID;
    }

    @Override
    public String toString(){
        String s = "";
        s += "Nome: " + nome + "città: " + citta + "chatID: " + chatID;
        return s; 
    }
    
}

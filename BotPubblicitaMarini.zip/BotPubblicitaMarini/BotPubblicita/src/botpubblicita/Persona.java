/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

/**
 *
 * @author marini_alessio
 */
public class Persona {

    String nome;
    Double[] coordinate;
    long chatID;

    public Persona(String nome, Double[] coordinate, long chatID) {
        this.nome = nome;
        this.coordinate = new Double[2];
        this.chatID = chatID;
    }

    @Override
    public String toString() {
        String s = "";
        s += "Nome: " + nome + "latitudine: " + coordinate[0] + "longitudine: " + coordinate[1] + "chatID: " + chatID;
        return s;
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

import TelegramAPI.Messaggio;
import TelegramAPI.Test;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marini_alessio
 */
public class getMessage {
    Test t;
    List<Messaggio> infoMessaggi;
    Persona P;

    public getMessage() {
        Test t = new Test();
        List<Messaggio> infoMessaggi = new ArrayList<Messaggio>();
    }
    
    
    public void run() throws IOException {
        infoMessaggi = t.getUpdates("getUpdates");
        for(Messaggio m : infoMessaggi)
        {
            String testo = m.getText();
            if(testo.startsWith("/registrazione "))
        {
                String nome = m.getUsername();
                String citta = testo.substring(15, testo.length());
                //dalla citta devo prendere le coordinate da OPENSTREETMAP
                long chatId = m.getIdChat();
                P = new Persona(nome, citta, chatId);
                //devo salvare i dati della persona o nel database o in un file csv
            }else {
                //invio un messaggio dicendo che non esiste come comando
            }
            
        }
        
    }
}

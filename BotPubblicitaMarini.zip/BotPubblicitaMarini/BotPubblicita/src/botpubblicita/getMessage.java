/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botpubblicita;

import TelegramAPI.Messaggio;
import TelegramAPI.Test;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marini_alessio
 */
public class getMessage {

    Test t = new Test();
    List<Messaggio> infoMessaggi = new ArrayList<>();
    Persona P;
    OSMthing OSM;

    public getMessage() {
    }

    public void run() throws IOException {
        infoMessaggi = t.getUpdates("getUpdates");
        for (Messaggio m : infoMessaggi) {
            String testo = m.getText();
            if (testo.startsWith("/registrazione ")) {
                String nome = m.getUsername();
                String citta = testo.substring(15, testo.length());
                long chatId = m.getIdChat();
                P = new Persona(nome, OSM.getSetCoordinates(citta), chatId);
                FileWriter fW = new FileWriter("prova.csv", true);
                fW.append(P.toString() + "\n");
                fW.flush();
                fW.close();
                //per leggere
//                Scanner s = new Scanner("prova.csv");
//                String line;
            } else {
                //invio un messaggio dicendo che non esiste come comando
            }
        }
//calcolare la distanza 
//lon1 = Math.toRadians(lon1);
//        lon2 = Math.toRadians(lon2);
//        lat1 = Math.toRadians(lat1);
//        lat2 = Math.toRadians(lat2);
// 
//        // Haversine formula
//        double dlon = lon2 - lon1;
//        double dlat = lat2 - lat1;
//        double a = Math.pow(Math.sin(dlat / 2), 2)
//                 + Math.cos(lat1) * Math.cos(lat2)
//                 * Math.pow(Math.sin(dlon / 2),2);
//             
//        double c = 2 * Math.asin(Math.sqrt(a));
// 
//        // Radius of earth in kilometers. Use 3956
//        // for miles
//        double r = 6371;
// 
//        // calculate the result
//        return(c * r);
    }
}

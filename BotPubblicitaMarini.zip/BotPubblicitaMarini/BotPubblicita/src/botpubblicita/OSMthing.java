/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package botpubblicita;

import java.io.IOException;
import java.io.StringReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

/**
 *
 * @author aless
 */
public class OSMthing {

    Double[] coordinate = new Double[2];

    public OSMthing() {
    }

    public Double[] getSetCoordinates(String citta) throws MalformedURLException, IOException {
        URL fileUrl = new URL("https://nominatim.openstreetmap.org/search?q=" + URLEncoder.encode(citta, StandardCharsets.UTF_8) + "&format=xml&addressdetails=1");
        Scanner inRemote = new Scanner(fileUrl.openStream());
        inRemote.useDelimiter("\u001a");
        String content = inRemote.next();

        Document tempDoc = convertStringToXMLDocument(content);
        //prendo le place dallo xml di openstreetmap
        NodeList Places = tempDoc.getElementsByTagName("place");
        //prendo l'item 0 della lista perché il primo risultato sarà quello che mi serve (si spera)
        Element el = (Element) Places.item(0);
        //nel primo metterò la latitudine e nella seconda la longitudine
        coordinate[0] = Double.parseDouble(el.getAttribute("lat"));
        coordinate[1] = Double.parseDouble(el.getAttribute("lon"));
        return coordinate;
    }

    private Document convertStringToXMLDocument(String xmlString) {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = null;
        try {
            builder = factory.newDocumentBuilder();
            Document doc = builder.parse(new InputSource(new StringReader(xmlString)));
            return doc;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

}

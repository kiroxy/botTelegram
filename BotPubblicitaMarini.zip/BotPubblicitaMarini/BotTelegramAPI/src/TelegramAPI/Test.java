/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TelegramAPI;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.json.*;

/**
 *
 * @author marini_alessio
 */
public class Test {
    String URLBase = "https://api.telegram.org/bot5199935935:AAFMcHp5SZNWk49S4fSUH4itKo99t1PIIpA/";

    public Test() {
    }

    public void sendMessage(String azione) throws MalformedURLException, IOException {
        String getUpdatesRequest = URLBase + azione;
        URL request = new URL(getUpdatesRequest);
        JSONObject obj= parsing(request);
    }

    public List<Messaggio> getUpdates(String azione) throws MalformedURLException, IOException {
        String getUpdatesRequest = URLBase + azione;
        URL request = new URL(getUpdatesRequest);
        JSONObject obj= parsing(request);
        JSONArray arrResult = obj.getJSONArray("result"); // notice that `"posts": [...]`
        
        List<Messaggio> tmp = new ArrayList<>();
        for (int i = 0; i < arrResult.length(); i++) {
            //ho il totale
            JSONObject totale = arrResult.getJSONObject(i);
            //entro nel messaggio
            JSONObject message = totale.getJSONObject("message");
            //long message_id = message.getLong("message_id");
            String text = message.getString("text");
            //entro nel from
            JSONObject from = message.getJSONObject("from");
            long id_chat = from.getLong("id");
            String first_name = from.getString("first_name");
            
            tmp.add(new Messaggio(id_chat,text,first_name));
            System.out.println(first_name);
        }
        return tmp;
        
    }

    //richiede l'url e ridà tutto lo xml
    public JSONObject parsing(URL request) throws IOException{
        String result = new BufferedReader(new InputStreamReader(request.openStream())).lines().collect(Collectors.joining("\n"));
        System.out.println(result);
        String jsonString = result; //assign your JSON String here
        JSONObject obj = new JSONObject(jsonString);
        return obj;
    }
    
}
